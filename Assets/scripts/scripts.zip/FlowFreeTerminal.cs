using UnityEngine;
using UnityEngine.UI;

public class FlowFreeTerminal : MonoBehaviour, IInteractable
{
    [Header("UI References")]
    public Text messageText;
    public GameObject flowFreeUI; // Atribuir o painel de UI do minijogo Flow Free aqui

    [Header("Settings")]
    public float accessTime = 3f;
    public string sceneToLoadOnComplete = "NextLevel";

    private bool isAccessing = false;
    private bool isGameActive = false;
    private float accessTimer = 0f;

    public string GetInteractMessage()
    {
        if (isGameActive)
            return "Game in progress...";

        if (isAccessing)
            return $"Accessing... {Mathf.Ceil(accessTime - accessTimer)}s";

        return "Press E to access terminal";
    }

    public void Interact(GameObject player)
    {
        if (isGameActive) return;

        if (!isAccessing)
        {
            // Iniciar o acesso ao terminal
            isAccessing = true;
            accessTimer = 0f;
        }
    }

    void Update()
    {
        // Tratar do temporizador de acesso
        if (isAccessing && !isGameActive)
        {
            accessTimer += Time.deltaTime;

            // Atualizar o texto da mensagem com o tempo restante
            if (messageText != null)
            {
                messageText.text = $"Accessing... {Mathf.Ceil(accessTime - accessTimer)}s";
            }

            // Verificar se o tempo de acesso está completo 
            if (accessTimer >= accessTime)
            {
                OpenMinigame();
            }
        }
    }

    void OpenMinigame()
    {
        isAccessing = false;
        isGameActive = true;

        // Mostrar a UI do minijogo Flow Free
        if (flowFreeUI != null)
        {
            flowFreeUI.SetActive(true);
        }

        // Pausar o jogo enquanto o minijogo está ativo
        Time.timeScale = 0f;

        // Desbloquear o cursor para interação no minijogo 
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;

        if (messageText != null)
        {
            messageText.text = "";
        }

        Debug.Log("Flow Free minigame opened!");
    }

    // Este método deve ser chamado pelo minijogo Flow Free quando o jogador o completa
    public void OnGameComplete()
    {
        isGameActive = false;

        // Esconder a UI do minijogo Flow Free
        if (flowFreeUI != null)
        {
            flowFreeUI.SetActive(false);
        }

        // Retomar o jogo
        Time.timeScale = 1f;

        // Bloquear o cursor novamente para o jogo normal
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        Debug.Log("Game completed! Loading scene: " + sceneToLoadOnComplete);

        // Carregar a próxima cena ou realizar outras ações necessárias após a conclusão
        UnityEngine.SceneManagement.SceneManager.LoadScene(sceneToLoadOnComplete);
    }
}