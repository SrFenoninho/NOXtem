using UnityEngine;

public class HitboxDefense : MonoBehaviour
{
    [Header("Defense Settings")]
    public GameObject defenseWallPrefab; // Preciso de desabafar, esta solução foi tão difícil de alcançar, gastei imenso tempo nisto, e sei que ainda há bugs mas estou a chegar mais perto de fazer uma boa defesa, já agora não sei o que estou a fazer!
    public Transform spawnPoint; 

    private GameObject currentDefenseWall;

    public void ActivateDefense()
    {
        if (currentDefenseWall != null) return;
        if (defenseWallPrefab != null && spawnPoint != null)
        {
            currentDefenseWall = Instantiate(defenseWallPrefab, spawnPoint.position, spawnPoint.rotation);
            Debug.Log("Defense wall created!");
        }
    }

    public void DeactivateDefense()
    {
        if (currentDefenseWall != null)
        {
            Destroy(currentDefenseWall);
            currentDefenseWall = null;
            Debug.Log("Defense wall destroyed!");
        }
    }
}