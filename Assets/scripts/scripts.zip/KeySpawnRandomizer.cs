using UnityEngine;

public class KeySpawnRandomizer : MonoBehaviour
{
    [Header("Key Spawn Points")]
    public GameObject[] keyObjects;

    void Start()
    {
        if (keyObjects.Length == 0)
        {
            return;
        }

        int randomIndex = Random.Range(0, keyObjects.Length); // Selecionar uma chave aleatória

        for (int i = 0; i < keyObjects.Length; i++)
        {
            if (i != randomIndex)
            {
                if (keyObjects[i] != null)
                {
                    Destroy(keyObjects[i]); // Destruir todas as chaves exceto a selecionada aleatoriamente
                }
            }
        }
    }
}