using UnityEngine;
using UnityEngine.UI;

public class Keys : MonoBehaviour, IInteractable
{
    [Header("Key Settings")]
    public string keyName = "Door"; // "Door" é apenas um exemplo de nome de chave

    [Header("UI")]
    public Text messageText;

    private bool alreadyPickedUp = false;

    public string GetInteractMessage()
    {
        return $"Press E to pick up {keyName} key.";
    }
    public void Interact(GameObject player)
    {
        if (alreadyPickedUp) return;

        PlayerKeys playerKeys = player.GetComponent<PlayerKeys>();

        if (playerKeys != null)
        {
            playerKeys.AddKey(keyName);
            alreadyPickedUp = true;

            if (messageText != null)
            {
                messageText.text = $"You picked up the key: {keyName}.";
                Invoke(nameof(ClearMessage), 2f);
            }

            GetComponent<Collider>().enabled = false; // Desativar futuras colisões

            MeshRenderer meshRenderer = GetComponent<MeshRenderer>();
            if (meshRenderer != null)
                meshRenderer.enabled = false; // Esconder o objeto da chave

            Destroy(gameObject, 2.1f);
        }
    }
    void ClearMessage()
    {
        if (messageText != null)
            messageText.text = "";
    }
}