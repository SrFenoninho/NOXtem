using UnityEngine;
using TMPro;                                    // TextMeshPro em vez do Text legado
using System.Collections;

public class PlayerComboSYS : MonoBehaviour
{
    [Header("UI Settings")]
    public TMP_Text comboText;                  // Arrastar o objeto TextMeshPro aqui no Inspector
    public string comboFormat = "COMBO x{0}";

    [Header("Combo Settings")]
    public float comboResetTime = 1f;           // Tempo sem acertar antes do combo reiniciar
    public int minimumComboToShow = 2;          // Só mostrar o contador a partir de x2

    [Header("Punch Scale Effect")]
    public float punchScale = 1.3f;             // Quão grande o texto fica a cada acerto
    public float punchDuration = 0.15f;         // Quão rápida é a animação de impacto

    private int currentCombo = 0;
    private float lastHitTime = 0f;
    private Vector3 originalScale;
    private Coroutine punchCoroutine;

    void Start()
    {
        if (comboText != null)
        {
            originalScale = comboText.transform.localScale;
            comboText.text = "";
            comboText.enabled = false;
        }
    }

    void Update()
    {
        // Reiniciar combo se não acertar dentro do comboResetTime
        if (currentCombo > 0 && Time.time - lastHitTime > comboResetTime)
            ResetCombo();
    }

    // Chamado por PlayerCombat.OnHitLanded() quando um ataque acerta
    public void RegisterHit()
    {
        currentCombo++;
        lastHitTime = Time.time;
        UpdateComboUI();
    }

    void UpdateComboUI()
    {
        if (comboText == null) return;

        if (currentCombo >= minimumComboToShow)
        {
            comboText.enabled = true;
            comboText.text = string.Format(comboFormat, currentCombo);

            // Efeito de escala de impacto a cada acerto
            if (punchCoroutine != null)
                StopCoroutine(punchCoroutine);
            punchCoroutine = StartCoroutine(PunchScale());
        }
        else
        {
            comboText.text = "";
            comboText.enabled = false;
        }
    }

    // Impacto de escala simples sem DOTween
    IEnumerator PunchScale()
    {
        float elapsed = 0f;

        // Escalar para cima
        while (elapsed < punchDuration / 2f)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / (punchDuration / 2f);
            comboText.transform.localScale = Vector3.Lerp(originalScale, originalScale * punchScale, t);
            yield return null;
        }

        elapsed = 0f;

        // Escalar para baixo
        while (elapsed < punchDuration / 2f)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / (punchDuration / 2f);
            comboText.transform.localScale = Vector3.Lerp(originalScale * punchScale, originalScale, t);
            yield return null;
        }

        comboText.transform.localScale = originalScale;
        punchCoroutine = null;
    }

    void ResetCombo()
    {
        currentCombo = 0;

        if (punchCoroutine != null)
        {
            StopCoroutine(punchCoroutine);
            punchCoroutine = null;
        }

        if (comboText != null)
        {
            comboText.transform.localScale = originalScale;
            comboText.text = "";
            comboText.enabled = false;
        }
    }

    public int GetCurrentCombo() => currentCombo;

    public void ForceReset() => ResetCombo();
}