using UnityEngine;
using System.Collections.Generic; // necessário para usar listas

public class PlayerKeys : MonoBehaviour
{
    private List<string> keys = new List<string>(); // list cria uma lista de strings

    public void AddKey(string keyID) // adicionar uma chave ao inventário do jogador
    {
        if (!keys.Contains(keyID))
        {
            keys.Add(keyID);
        }
    }

    public bool HasKey(string keyID) // verificar se o jogador tem uma chave
    {
        return keys.Contains(keyID);
    }

    public void RemoveKey(string keyID) // remover uma chave do inventário do jogador
    {
        keys.Remove(keyID);
    }
}