using UnityEngine;

public class PlayerPush : MonoBehaviour
{
    public float pushForce = 5f; // Força aplicada ao objeto quando a colisão do jogador colide com ele

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody rb = hit.collider.attachedRigidbody;

        if (rb == null || rb.isKinematic)
            return;

        Vector3 pushDir = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z);

        rb.AddForce(pushDir * pushForce, ForceMode.Impulse);
    }
}
