using UnityEngine;

public class StartChaseTrigger : MonoBehaviour
{
    public MonsterChaseAI monster;   // Outra vez, chamar-lhe "IA" já é dizer muito, mas pronto :)

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            monster.StartChasing();
            gameObject.SetActive(false); // desativar o trigger após a ativação por razões óbvias
        }
    }
}
